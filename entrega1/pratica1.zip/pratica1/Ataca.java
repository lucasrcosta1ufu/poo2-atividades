
/**
 * Write a description of class Ataca here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public interface Ataca
{
    public void atacar();
}
