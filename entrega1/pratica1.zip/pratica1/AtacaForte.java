
/**
 * Write a description of class AtacaForte here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class AtacaForte implements Ataca
{
    public void atacar(){
        System.out.printf("Ataque Forte.\n");
    }
}
