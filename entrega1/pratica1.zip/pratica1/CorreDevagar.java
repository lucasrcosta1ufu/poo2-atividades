
/**
 * Write a description of class CorreDevagar here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class CorreDevagar implements Corre
{
    public void correr(){
        System.out.printf("Corre Devagar.\n");
    }
}
