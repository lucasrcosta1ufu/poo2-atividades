
/**
 * Write a description of class CorreMedio here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class CorreMedio implements Corre
{
    public void correr(){
        System.out.printf("Corre Medio.\n");
    }
}
