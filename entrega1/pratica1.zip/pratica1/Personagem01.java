
/**
 * Write a description of class Personagem01 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Personagem01 extends Personagem
{
    public Personagem01(){
        setP(new PulaMedio());
        setC(new CorreMedio());
        setA(new AtacaForte());
    }
}
