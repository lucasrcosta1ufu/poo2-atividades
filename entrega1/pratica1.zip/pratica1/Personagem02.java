
/**
 * Write a description of class Personagem02 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Personagem02 extends Personagem
{
    public Personagem02(){
        setP(new PulaAlto());
        setC(new CorreRapido());
        setA(new AtacaMedio());
    }
}