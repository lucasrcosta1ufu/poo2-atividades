
/**
 * Write a description of class Personagem03 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Personagem03 extends Personagem
{
    public Personagem03(){
        setP(new PulaBaixo());
        setC(new CorreRapido());
        setA(new AtacaForte());
    }
}