
/**
 * Write a description of class Pula here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public interface Pula
{
    public void pular();
}
