
/**
 * Write a description of class PulaAlto here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class PulaAlto implements Pula
{
    public void pular(){
        System.out.printf("Pulo Alto.\n");
    }
}
