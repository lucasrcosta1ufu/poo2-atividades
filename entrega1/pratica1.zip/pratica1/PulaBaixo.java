
/**
 * Write a description of class PulaBaixo here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class PulaBaixo implements Pula
{
    public void pular(){
        System.out.printf("Pulo Baixo.\n");
    }
}
