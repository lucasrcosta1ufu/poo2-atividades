
/**
 * Write a description of class PulaMedio here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class PulaMedio implements Pula
{
    public void pular(){
        System.out.printf("Pulo Medio.\n");
    }
}
