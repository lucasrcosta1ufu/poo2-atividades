
/**
 * Write a description of class AtacaFraco here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class AtacaFraco implements Ataca
{
    public void atacar(){
        System.out.printf("Ataque Fraco.\n");
    }
}
