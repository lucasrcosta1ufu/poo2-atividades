
/**
 * Write a description of class AtacaMedio here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class AtacaMedio implements Ataca
{
    public void atacar(){
        System.out.printf("Ataque Medio.\n");
    }
}
