
/**
 * Write a description of class CorreRapido here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class CorreRapido implements Corre
{
    public void correr(){
        System.out.printf("Corre Rapido.\n");
    }
}
