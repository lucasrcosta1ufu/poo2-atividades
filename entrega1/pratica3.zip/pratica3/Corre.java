
/**
 * Write a description of class Corre here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public interface Corre
{
    public int correr();
}
