
/**
 * Write a description of class CorreDevagar here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class CorreDevagar implements Corre
{
    private int velocidade = 5;
    public int correr() {
        return velocidade;
    }
}
