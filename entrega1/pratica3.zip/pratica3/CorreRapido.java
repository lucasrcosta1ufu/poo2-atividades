
/**
 * Write a description of class CorreRapido here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class CorreRapido implements Corre
{
    private int velocidade = 15;
    public int correr() {
        return velocidade;
    }
}
