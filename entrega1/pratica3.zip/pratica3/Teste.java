

public class Teste
{
    public static void main(String args[])throws InterruptedException {

            Game g = new Game();
            g.jogar(g);
    
    }
}
