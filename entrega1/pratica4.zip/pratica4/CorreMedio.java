
/**
 * Write a description of class CorreMedio here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class CorreMedio implements Corre
{
    private int velocidade = 10;
    public int correr() {
        return velocidade;
    }
}
