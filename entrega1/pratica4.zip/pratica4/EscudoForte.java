
import java.awt.image.BufferedImage;
/**
 * Write a description of class EscudoForte here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class EscudoForte extends Escudo
{
    public EscudoForte () {
        super("./res/escudoForte.png", 5);
    }
}

