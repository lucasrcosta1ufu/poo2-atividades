
import java.awt.image.BufferedImage;
/**
 * Write a description of class EscudoMedio here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class EscudoMedio extends Escudo
{
    public EscudoMedio () {
        super("./res/escudoMedio.png", 3);
    }
}
